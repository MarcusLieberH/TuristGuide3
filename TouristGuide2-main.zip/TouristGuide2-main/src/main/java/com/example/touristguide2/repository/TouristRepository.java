package com.example.touristguide2.repository;

import com.example.touristguide2.model.TouristAttraction;
import com.example.touristguide2.model.TouristTags;
import com.example.touristguide2.model.TouristTowns;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

@Repository
public class TouristRepository {
    private final List<TouristAttraction> attractionList = new ArrayList<>();

    public TouristRepository() {
        populateAttractions();

    }

    private void populateAttractions() {
        TouristAttraction tivoli = new TouristAttraction(
                "Tivoli Haven",
                "Historisk forlystelsespark med traditionel charme og moderne underholdning",
                TouristTowns.KOBENHAVN,
                Arrays.asList(TouristTags.FORLYSTELSER, TouristTags.HISTORIE, TouristTags.UNDERHOLDNING)
        );
        tivoli.setImage("https://cdn.tivoli.dk/media/z5zfn5hy/hovedindgangen-tivoli-sommer-2022-14631671.jpg?height=675&width=1200&format=jpeg");
        attractionList.add(tivoli);

        TouristAttraction segway = new TouristAttraction(
                "Segway Tours Copenhagen",
                "Miljøvenlig guidet tur, der giver unikt indblik i Københavns kultur og arkitektur.",
                TouristTowns.KOBENHAVN,
                Arrays.asList(TouristTags.GUIDED_TUR, TouristTags.MILJOE_VENLIG, TouristTags.KULTUR)

        );
        segway.setImage("https://media-cdn.tripadvisor.com/media/attractions-splice-spp-674x446/06/72/fe/fe.jpg"); // Tilføj billede
        attractionList.add(segway);

        TouristAttraction kanalrundfart = new TouristAttraction(
                "Hop on – Hop off kanalrundfart",
                "Fleksibel sejltur, hvor man i eget tempo udforsker byens kanaler og vartegn.",
                TouristTowns.KOBENHAVN,
                Arrays.asList(TouristTags.SEJLTUR, TouristTags.BYVANDRING)
        );
        kanalrundfart.setImage("https://gdkfiles.visitdenmark.com/files/382/302413_Classic_Canal_Tour_CVS_1024x576.jpg?width=987");
        attractionList.add(kanalrundfart);

        TouristAttraction havfrue = new TouristAttraction(
                "Den Lille Havfrue",
                "Ikonisk bronzestatue inspireret af H.C. Andersens eventyr og Københavns kulturarv.",
                TouristTowns.KOBENHAVN,
                Arrays.asList(TouristTags.STATUE, TouristTags.KULTUR)
        );
        havfrue.setImage("https://files.guidedanmark.org/files/382/83168_The_Little_Mermaid.jpg");
        attractionList.add(havfrue);

        TouristAttraction nyhavn = new TouristAttraction(
                "Nyhavn",
                "Farverigt havneområde med historiske facader, caféer og livlig atmosfære.",
                TouristTowns.KOBENHAVN,
                Arrays.asList(TouristTags.HAVN, TouristTags.HISTORIE, TouristTags.CAFÉER)
        );
        nyhavn.setImage("https://gdkfiles.visitdenmark.com/files/382/164757_Nyhavn_Jacob-Schjrring-og-Simon-Lau.jpg?width=987");
        attractionList.add(nyhavn);

        TouristAttraction christiania = new TouristAttraction(
                "Fristaden Christiania",
                "Alternativ bydel med selvstyre, kreativ kultur og unik samfundsstruktur.",
                TouristTowns.KOBENHAVN,
                Arrays.asList(TouristTags.ALTERNATIV, TouristTags.KREATIV, TouristTags.SAMFUND)
        );
        christiania.setImage("https://files.guidedanmark.org/files/382/173183__MG_2000.jpg_beskret.jpg");
        attractionList.add(christiania);

        TouristAttraction amalienborg = new TouristAttraction(
                "Amalienborg Slot",
                "Kongelig residens i rokokostil, centrum for ceremonielle begivenheder.",
                TouristTowns.KOBENHAVN,
                Arrays.asList(TouristTags.KONGELIG, TouristTags.HISTORIE)
        );
        amalienborg.setImage("https://gdkfiles.visitdenmark.com/files/382/171919_Amalienborg_sunset_Martin_Heiberg.jpg");
        attractionList.add(amalienborg);

        TouristAttraction rosenborg = new TouristAttraction(
                "Rosenborg Slot",
                "Renæssanceslot og museum, der huser kongelige skatte og formidler Danmarks historie.",
                TouristTowns.KOBENHAVN,
                Arrays.asList(TouristTags.MUSEUM, TouristTags.HISTORIE, TouristTags.SLOT)
        );
        rosenborg.setImage("https://www.kongernessamling.dk/wp-content/uploads/2018/11/Rosenborg_Oestvendt_Facade_01-480x400.jpg");
        attractionList.add(rosenborg);
    }


    /* En metode til at returnere hele listen af attraktioner */
    public List<TouristAttraction> getAllAttractions() {
        return attractionList;
    }

    /* En metode, der modtager et ID som parameter, itererer listen og returnerer den attraktion, der matcher ID'et. */
    public TouristAttraction getAttractionByName(String name) {
        for (TouristAttraction touristAttraction : attractionList) {
            if (touristAttraction.getName().equalsIgnoreCase(name)) {
                return touristAttraction;
            }
        }
        return null;
    }

    public TouristAttraction updateAttraction(TouristAttraction input) {
        for (TouristAttraction attraction : attractionList) {
            if (attraction.getName().equalsIgnoreCase(input.getName())) {
                attraction.setName(input.getName());
                attraction.setDescription(input.getDescription());
                attraction.setTown(input.getTowns());
                attraction.setTags(input.getTags());
                return attraction;
            }
        }
        return null;
    }



    /*En metode, der modtager de nødvendige data  ( Navn og beskrivelse) og opretter et nyt TouristAttraction-objekt.*/
    public TouristAttraction addAttraction(TouristAttraction attraction) {
        attractionList.add(attraction);
        return attraction;


    }

    //En metode til at fjerne en attraktion baseret på dens unikke ID
    public boolean deleteAttraction(String name) {
        Iterator<TouristAttraction> iterator = attractionList.iterator();
        while (iterator.hasNext()) {
            TouristAttraction attraction = iterator.next();
            if (attraction.getName().equals(name)) {
                iterator.remove();
                return true;
            }
        }
        return false;
    }
    public List<TouristTags> getAttractionTags(String name) {
        TouristAttraction attraction = getAttractionByName(name);
        return (attraction != null) ? attraction.getTags() : List.of();
    }

}

